﻿using System;

namespace ListenerRoutingLib
{
    public class paibanModel
    {


        //以下是生成的属性
        public Int32 id { get; set; }

        public String BedNo { get; set; }
        public String Height { get; set; }

        public String Weight { get; set; }

        public DateTime ApplyDate { get; set; }
        public DateTime Odate { get; set; }

        public String patName { get; set; }

        public String patage { get; set; }

        public String patsex { get; set; }

        public String patMinZu { get; set; }

        public String patdpm { get; set; }

        public String SQZD { get; set; }

        public String IsZhuYuan { get; set; }

        public String Oname { get; set; }

        public String ASAE { get; set; }

        public String operAddress { get; set; }

        public String OsNo { get; set; }
        public String OA1No { get; set; }
        public String OA2No { get; set; }
        public String OA3No { get; set; }
        public String OA1 { get; set; }
        public String OA2 { get; set; }
        public String OA3 { get; set; }
        public String OS { get; set; }

        public String Olevel { get; set; }

        public String MZFA { get; set; }

        public String PATID { get; set; }

        public String zhuyuanNO { get; set; }

        public String applyID { get; set; }

        public String cardNO { get; set; }

    }
}
